<!--
  ============================================================
  CYBERSECURITY CLUB – SUBPAGE TEMPLATE
  ============================================================
  HOW TO USE:
  1. Replace all text inside [brackets] with your own content.
  2. To add a logo: put an image named `logo.png` (or .jpg) 
     inside the `media/` folder next to this file.
  3. To add gallery images: drop any other images into the 
     `media/` folder. They will automatically appear in the 
     Gallery section as a slideshow.
  4. Delete any sections you don't need. Keep the `##` headings 
     for the sections you want to keep.
  5. Do NOT change the `#` heading at the top – that's the page title.
  ============================================================

  Your page's folder should be structured:
    subpages/
    └── your-page-name/
        ├── webpage.md
        └── media/
            ├── logo.png          ← page logo (referenced in markdown)
            ├── event-photo.jpg   ← carousel
            ├── team.png          ← carousel
            └── another.jpg       ← carousel 
            (carousel loops through everything in media/ aside from the logo.png)

-->

# Cyberwarfare and National Security

> We are a research group focused heavily on cybersecurity within the context of Warfare. 

![Team Logo](media/logo.png)

---

## About

[Write a longer description here. You can use multiple paragraphs.  
This is a good place to talk about your team's mission, history, or goals.]
Our main focus is how compututing systems are used by nationstates to conduct warfare operations. 
Our trainings tend to go into several aspects of the field ranging from which nations are involved to the kinds of malware used
and even what is affected physically. Some focuses of our rig include
-Tactics,Techniques, Procedures used by APTS
-Offensive security and Malware Analysis
-Incident response and Digital Forensics

[

## Gallery

<!--
  ⚠️ DO NOT EDIT THIS SECTION.
  Just drop images into the `media/` folder. 
  They will automatically appear here as a slideshow.
  (The file `logo.png` is reserved for the page logo and will not appear in the slideshow.)
-->

]
## Mission
We hope to prepare our students to understand the signs of an ongoing cyberattack and be able to respond promptly. We want to ensure
they know the risks our nations industries and miltiary faces as cyberspace continues to evolve.

## What We Do
Our research group specializes in hands-on training including topics such as
-live fire exercises
-case studies
-tool training/workshops

## Team


- Hondo Limon – CWNS Lead
- Gabriel Green – CWNS Lead
- Adithyaa Sivamal - CWNS Assistant Lead

## Schedule


Wednesdays - 6:30 PM - 1.202 NPB Main Campus
Thusrdays  - 6:30 PM - 1.202 NPB Main Campus


## Contact

[How can people reach you? Email, Discord, social media, etc.]

- Discord: https://discord.gg/sthbyPkDRx