<!--
  ============================================================
  CYBERSECURITY CLUB – SUBPAGE TEMPLATE
  ============================================================
  HOW TO USE:
  1. Replace all text inside [brackets] with your own content.
  2. To add a logo: put an image named `logo.png` (or .jpg) 
     inside the `media/` folder next to this file.
  3. To add gallery images: drop any other images into the 
     `media/` folder. They will automatically appear in the 
     Gallery section as a slideshow.
  4. Delete any sections you don't need. Keep the `##` headings 
     for the sections you want to keep.
  5. Do NOT change the `#` heading at the top – that's the page title.
  ============================================================

  Your page's folder should be structured:
    subpages/
    └── your-page-name/
        ├── webpage.md
        └── media/
            ├── logo.png          ← page logo (referenced in markdown)
            ├── event-photo.jpg   ← carousel
            ├── team.png          ← carousel
            └── another.jpg       ← carousel 
            (carousel loops through everything in media/ aside from the logo.png)

-->

# [Your Page Title]

> [A short, one-sentence description of this page or team.]

![Team Logo](media/logo.png)

---

## About

[Write a longer description here. You can use multiple paragraphs.  
This is a good place to talk about your team's mission, history, or goals.]

- [Bullet point 1]
- [Bullet point 2]
- [Bullet point 3]

[Optional link](https://example.com)

## Gallery

<!--
  ⚠️ DO NOT EDIT THIS SECTION.
  Just drop images into the `media/` folder. 
  They will automatically appear here as a slideshow.
  (The file `logo.png` is reserved for the page logo and will not appear in the slideshow.)
-->

## Mission

[Describe your mission or purpose. What does your team aim to achieve?]

## What We Do

[Explain the activities, projects, or services your team provides.]

- [Activity 1]
- [Activity 2]
- [Activity 3]

## Team

[List team members, roles, or leads. You can use bullet points or a simple table.]

- **[Name]** – [Role]
- **[Name]** – [Role]

## Events

[Upcoming or past events, meetings, or workshops.]

- [Event Name] – [Date] – [Short description]
- [Event Name] – [Date] – [Short description]

## Projects

[Highlight current or past projects.]

- **[Project Name]** – [Brief description]
- **[Project Name]** – [Brief description]

## Resources

[Links to tools, documentation, or learning materials.]

- [Resource 1](https://example.com)
- [Resource 2](https://example.com)

## Contact

[How can people reach you? Email, Discord, social media, etc.]

- Email: [email@example.com]
- Discord: [invite link]
- Twitter: [@handle]
