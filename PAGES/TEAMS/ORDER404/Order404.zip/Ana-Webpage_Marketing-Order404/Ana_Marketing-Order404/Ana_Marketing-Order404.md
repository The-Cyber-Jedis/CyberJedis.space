<!--
  ============================================================
  CYBERSECURITY CLUB – SUBPAGE TEMPLATE
  ============================================================
  HOW TO USE:
  1. Replace all text inside [brackets] with your own content.
  2. To add a logo: put an image named `logo.png` (or .jpg) 
     inside the `media/` folder next to this file.
  3. To add gallery images: drop any other images into the 
     `media/` folder. They will automatically appear in the 
     Gallery section as a slideshow.
  4. Delete any sections you don't need. Keep the `##` headings 
     for the sections you want to keep.
  5. Do NOT change the `#` heading at the top – that's the page title.
  ============================================================

  Your page's folder should be structured:
    subpages/
    └── your-page-name/
        ├── webpage.md
        └── media/
            ├── logo.png          ← page logo (referenced in markdown)
            ├── event-photo.jpg   ← carousel
            ├── team.png          ← carousel
            └── another.jpg       ← carousel 
            (carousel loops through everything in media/ aside from the logo.png)

-->

# [Ana Moreno]

> [I just graduated this past summer with a BBA in Cybersecurity, and I am continuing my academic journey by earning an MS in Cybersecurity here at UTSA.]

![Team Logo](media/logo.png)

---

## About

[I joined this organization back in Fall 2025 and ever since then I have taken on more responsibility. I became a marketing officer, as well as taking on filming and editing videos. I also joined Vincent, one of the other marketing officers, in Order404. And now, we have been focusing on growing Order404 and hope to get more members to participate.]

- [Marketing officer]
- [Filming/Editing]
- [Member of Order404]


## Gallery

<!--
  ⚠️ DO NOT EDIT THIS SECTION.
  Just drop images into the `media/` folder. 
  They will automatically appear here as a slideshow.
  (The file `logo.png` is reserved for the page logo and will not appear in the slideshow.)
-->

## Mission

[As a marketing officer, I strive to capture and announce any events that we have done or that upcoming. We may plan events, but if we don't post anything about, then it would be pointless. That's why I like being a marketing officer. I like being the messenger.

For Order404, we really want to get more members to participate. Order404 is about cybersecurity, creativity, and controlled chaos, and we hope to get the ball rolling this semester!]

## What We Do

[Explain the activities, projects, or services your team provides.]

- [Create posts for Instagram/LinkedIn/Discord]
- [Help announce events in all of our social medias]
- [Film and edit]

## Projects

[Highlight current or past projects.]

- **[Meet The Officers]** – [This was a video that I edited last semester (Spring 2026), and it was a introductory video of our officers at that time. It was edited in the theme of 'Friends', and it had the theme song playing in the background. You can check it out on the Cyber Jedis Instagram and LinkedIn page.]
- **[Project Name]** – [Brief description]

## Contact

[How can people reach you? Email, Discord, social media, etc.]

- Email: [ana.moreno@my.utsa.edu]
- Discord: [https://discord.com/users/1438385342179971226]
- LinkedIn: [www.linkedin.com/in/anamoreno2026]
